import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("healthexp.csv")

# Select only numeric columns
X = df.select_dtypes(include=['int64', 'float64'])

# Handle missing values
X = X.fillna(X.mean())

# Feature scaling (important for clustering)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Apply K-Means
k = 3   # you can change this
model = KMeans(n_clusters=k, random_state=0)
clusters = model.fit_predict(X_scaled)
# Add cluster labels to dataset
df['Cluster'] = clusters

# Simple visualization (first 2 columns)
plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=clusters)
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.title("K-Means Clustering")
plt.show()
# Output
print(df.head())