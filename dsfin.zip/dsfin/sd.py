import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns   # added

df = pd.read_csv("healthexp.csv")

# EDA (basic)
print(df.head())
print(df.describe())
print(df.isnull().sum())

# Visualization
df.hist()
plt.show()

plt.scatter(df.iloc[:, 0], df.iloc[:, 1])
plt.show()

# Heatmap (added)
corr = df.corr(numeric_only=True)
sns.heatmap(corr, annot=True, cmap="coolwarm")
plt.show()